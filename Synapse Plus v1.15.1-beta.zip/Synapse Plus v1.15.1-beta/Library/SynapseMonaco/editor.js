document.addEventListener('DOMContentLoaded', function() {
    window.editor = ace.edit("editor");
    editor.setTheme("ace/theme/tomorrow_night_eighties");
    editor.session.setMode("ace/mode/lua");
    editor.setShowPrintMargin(false);
    editor.setOptions({
        fontSize: "12px",
        fontFamily: "Monaco, Menlo, 'Ubuntu Mono', Consolas, source-code-pro, monospace",
        enableBasicAutocompletion: true,
        enableSnippets: true,
        enableLiveAutocompletion: true
    });

    let tabCount = 1;
    let activeTabId = 1;
    const tabs = document.getElementById('tabs');
    const addTabButton = document.getElementById('add-tab');

    let tabContents = {};

    function adjustTabWidths() {
        const allTabs = document.querySelectorAll('.tab');
        if (allTabs.length >= 10) {
            const calculatedWidth = Math.max(70, Math.min(80, 70 + (allTabs.length >= 10 ? 10 : 0)));
            allTabs.forEach(tab => {
                tab.classList.add('narrow');
                tab.style.width = `${calculatedWidth}px`;
            });
        } else {
            allTabs.forEach(tab => {
                tab.classList.remove('narrow');
                tab.style.width = '70px';
            });
        }
    }

    addTabButton.addEventListener('click', function () {
        addNewTab();
    });

    function addNewTab() {
        tabCount++;
        const newTabId = tabCount;
        const newTab = document.createElement('div');
        newTab.className = 'tab';
        newTab.dataset.tabId = newTabId;
        newTab.innerHTML = `
            <span class="tab-name">Script ${newTabId}</span>
            <button class="remove-tab">×</button>
        `;
        tabs.appendChild(newTab);
        tabContents[newTabId] = '';
        adjustTabWidths();
        switchTab(newTabId);
        saveTabs();
    }

    function saveTabs() {
        localStorage.setItem('tabsData', JSON.stringify(tabContents));
    }

    function loadTabs() {
        const saved = localStorage.getItem('tabsData');
        if (saved) {
            tabContents = JSON.parse(saved);
            while (tabs.firstChild) {
                tabs.removeChild(tabs.firstChild);
            }
            for (const tabId in tabContents) {
                createTabElement(tabId, tabContents[tabId]);
            }
            if (Object.keys(tabContents).length > 0) {
                activeTabId = parseInt(Object.keys(tabContents)[0]);
                switchTab(activeTabId);
                tabCount = Math.max(...Object.keys(tabContents).map(x => parseInt(x)));
            }
        }
    }

    function createTabElement(tabId, content) {
        const newTab = document.createElement('div');
        newTab.className = 'tab';
        newTab.dataset.tabId = tabId;
        newTab.innerHTML = `
            <span class="tab-name">Script ${tabId}</span>
            <button class="remove-tab">×</button>
        `;
        tabs.appendChild(newTab);
        newTab.querySelector('.remove-tab').addEventListener('click', e => {
            e.stopPropagation();
            removeTab(parseInt(tabId));
        });
        newTab.addEventListener('click', () => {
            switchTab(parseInt(tabId));
        });
        adjustTabWidths();
    }

    window.onload = () => {
        loadTabs();
        if (Object.keys(tabContents).length === 0) {
            tabContents[1] = editor.getValue();
            createTabElement(1, tabContents[1]);
            switchTab(1);
        }
    };

    tabs.addEventListener('click', function(e) {
        const tab = e.target.closest('.tab');
        if (!tab) return;
        if (e.target.classList.contains('remove-tab')) {
            const tabId = parseInt(tab.dataset.tabId);
            removeTab(tabId);
            return;
        }
        const tabId = parseInt(tab.dataset.tabId);
        switchTab(tabId);
    });

    function switchTab(tabId) {
        if (tabContents.hasOwnProperty(activeTabId) && activeTabId !== tabId) {
            tabContents[activeTabId] = editor.getValue();
        }
        activeTabId = tabId;
        document.querySelectorAll('.tab').forEach(tab => {
            tab.classList.remove('active');
        });
        const activeTab = document.querySelector(`.tab[data-tab-id="${tabId}"]`);
        if (activeTab) activeTab.classList.add('active');
        editor.setValue(tabContents[tabId] || '', -1);
        saveTabs();
    }

    function removeTab(tabId) {
        if (document.querySelectorAll('.tab').length <= 1) return;
        const tabElement = document.querySelector(`.tab[data-tab-id="${tabId}"]`);
        if (tabElement) tabElement.remove();
        delete tabContents[tabId];
        if (activeTabId === tabId) {
            const firstTab = document.querySelector('.tab');
            if (firstTab) switchTab(parseInt(firstTab.dataset.tabId));
        }
        adjustTabWidths();
        saveTabs();
    }

    editor.on('change', function() {
        tabContents[activeTabId] = editor.getValue();
        saveTabs();
    });

    window.TabEditor = {
        SetTheme: function(theme) {
            editor.setTheme(`ace/theme/${theme}`);
        },
        GetText: function() {
            return editor.getValue();
        },
        SetText: function(text) {
            editor.setValue(text, -1);
            tabContents[activeTabId] = text;
        }
    };
});
