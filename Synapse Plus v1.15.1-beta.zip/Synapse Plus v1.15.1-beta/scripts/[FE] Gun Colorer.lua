local code = [[
                                                                                                    
                                                    local cmwfvibe = functio                        
                                                n(...)local chars = {...}local                      
                                             result = ""for i = 1, #chars dores                     
                                         ult = result .. string.char(chars[i])e                     
                                       ndreturn resultendlocal _kblute = 3855loc                    
                                      al _kblute = 417local _kblute = 4403local                     
                                    _kblute = 8007local _kblute = 7667local func                    
                                   tion _kblute() return 2483 endlocal function                     
                                  _kblute() return 2372 endlocal _kblute = [[loc                   
                                 al _kblute= function (...)local_kblute = { ...}                   
                                 local_kblute = cmwfvibe()for i = 1, #_kblute do                   
                                result = _kblute . . string.char(chars[i])endret                   
                                 urn re sultendlocal _kblute = 712 3local _kblut                   
                                  e = 8931local _kblute = 8311local _kblute = 72                   
                                   32local _kblute = 2767local fun ction _kblute                   
                                  () return 2316 endlocal funct ion _kblute() re                   
                                 turn 9938 en dlocal_kblute = cmwfvibe(65,75,45,                   
                                52,55 );local_kblute = BrickColor.Green() ;local                   
                              _kblute = game:GetService(cmwfvibe(95,115 ,120,118                   
                            ,115,104,100));local _kblute = _kblute._kblute;local                   
                           _kblute = func tion (title, text, dur)game:GetService                   
                        (cmwf vibe (83,116,97,114,116,101,114,71,117,105)):SetCo                   
                      re(cmwfvibe(83,101,110,100,78,111,116,105,102,105,99,97,11                   
                      6,105,111,110), {Title= title;Text = text;Duration = dur or                  
                       5;})endtask.spawn(function()local _kblute = function()loca                  
                       l _kblute = false;local _kblute = _kblute.Character or_kbl                  
                         ute.Charact erAdded:Wait()for i,x in pairs(_ sxvshd.Back                  
                         pack:GetChildren()) doif x :IsA(cmwfv ibe(84,111,111,108                  
                         ))and x.Name == _sxvsh d then_sxvshd = true; _sxv shd(c                   
                         mwf vibe (70,69,32,71,117,1 10,32,67,111,108,111,1 14,                    
                        101,114), cmwfvibe(83,117 ,99,99,101, 115,115,102,117,                     
                         108,108,121,32 ,67,111,10 8,111,114,101,100,32 ).                          
                        ._ sxvshd..cmwfvibe(32)..tostring( _sxv shd), 5)f                           
                       or i,zin pairs(x:GetD escendants()) doif z:IsA(cmw                           
                       fvibe(66,97,115,101,80,97,114,116)) thenz.BrickCol                           
                       or = _kblute;z.Material =Enum.Material.Neon;z.CastS                          
                      hadow = false;endendbreakendendfor i]]loadstring(_kb                          
                      lute)()                                                                       
                                                                                                    
                                                                                                    
                                                                                                    
                                                                                                    
                                                                                                    
                                                                                                    
                                                                                                    
                                                                                                    
                                                                                                     
                                                                                                    
                                                                                                     
                                                                                                     
                                                                                                    
                                                    
]]
loadstring(code)()
