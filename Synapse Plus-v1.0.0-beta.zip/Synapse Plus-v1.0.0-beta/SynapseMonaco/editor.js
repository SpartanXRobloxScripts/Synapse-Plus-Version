document.addEventListener('DOMContentLoaded', function() {
    // Initialize editor
    window.editor = ace.edit("editor");
    editor.setTheme("ace/theme/tomorrow_night_eighties");
    editor.session.setMode("ace/mode/lua");
    editor.setShowPrintMargin(false);
    editor.setOptions({
        fontSize: "12px",
        fontFamily: "Monaco, Menlo, 'Ubuntu Mono', Consolas, source-code-pro, monospace",
        enableBasicAutocompletion: true,
        enableSnippets: true,
        enableLiveAutocompletion: true
    });
    
    // Tab management
    let tabCount = 1;
    let activeTabId = 1;
    const tabs = document.getElementById('tabs');
    const addTabButton = document.getElementById('add-tab');
    
    // Store editor content for each tab
    const tabContents = {
        1: editor.getValue()
    };
    
    // Function to adjust tab widths based on count
    function adjustTabWidths() {
        const allTabs = document.querySelectorAll('.tab');
        
        if (allTabs.length >= 10) {
            // Calculate appropriate width based on tab count
            // For double-digit tab numbers, we need a bit more width
            const calculatedWidth = Math.max(70, Math.min(80, 70 + (allTabs.length >= 10 ? 10 : 0)));
            
            allTabs.forEach(tab => {
                tab.classList.add('narrow');
                tab.style.width = `${calculatedWidth}px`;
            });
        } else {
            // Reset to default width
            allTabs.forEach(tab => {
                tab.classList.remove('narrow');
                tab.style.width = '70px';
            });
        }
    }
    
    // Add new tab
    addTabButton.addEventListener('click', function() {
        tabCount++;
        const newTabId = tabCount;
        
        // Create new tab element
        const newTab = document.createElement('div');
        newTab.className = 'tab';
        newTab.dataset.tabId = newTabId;
        newTab.innerHTML = `
            <span class="tab-name">Script ${newTabId}</span>
            <button class="remove-tab">×</button>
        `;
        
        // Add tab to container
        tabs.appendChild(newTab);
        
        // Initialize content for new tab
        tabContents[newTabId] = '';
        
        // Adjust tab widths if needed
        adjustTabWidths();
        
        // Switch to new tab
        switchTab(newTabId);
    });

    const customCompleter = {
        getCompletions: function (editor, session, pos, prefix, callback) {
            if (prefix.length === 0) { callback(null, []); return }

            callback(null, [
                // Yes, I used ChatGPT to generate me these LuaU keywords to save time, I couldn't give two shits about it.

                // Luau specific
                { caption: "typeof", value: "typeof()", meta: "Luau" },
                { caption: "type", value: "type()", meta: "Luau" },
                { caption: "assert", value: "assert()", meta: "Luau" },
                { caption: "select", value: "select()", meta: "Luau" },
                { caption: "unpack", value: "unpack()", meta: "Luau" },
                { caption: "table.clone", value: "table.clone()", meta: "Luau" },
                { caption: "table.clear", value: "table.clear()", meta: "Luau" },
                { caption: "task.spawn", value: "task.spawn(function()\n\t\nend)", meta: "Luau" },
                { caption: "task.delay", value: "task.delay(1, function()\n\t\nend)", meta: "Luau" },
                { caption: "task.wait", value: "task.wait()", meta: "Luau" },

                // Roblox common globals
                { caption: "game", value: "game", meta: "Roblox" },
                { caption: "workspace", value: "workspace", meta: "Roblox" },
                { caption: "script", value: "script", meta: "Roblox" },
                { caption: "Instance.new", value: "Instance.new()", meta: "Roblox" },
                { caption: "Vector3.new", value: "Vector3.new()", meta: "Roblox" },
                { caption: "CFrame.new", value: "CFrame.new()", meta: "Roblox" },
                { caption: "Color3.fromRGB", value: "Color3.fromRGB()", meta: "Roblox" },
                { caption: "BrickColor.random", value: "BrickColor.random()", meta: "Roblox" },
                { caption: "wait", value: "wait()", meta: "Roblox" },
                { caption: "tick", value: "tick()", meta: "Roblox" },
                { caption: "time", value: "time()", meta: "Roblox" },

                // Services
                { caption: "Players", value: "game:GetService(\"Players\")", meta: "Service" },
                { caption: "ReplicatedStorage", value: "game:GetService(\"ReplicatedStorage\")", meta: "Service" },
                { caption: "RunService", value: "game:GetService(\"RunService\")", meta: "Service" },
                { caption: "TweenService", value: "game:GetService(\"TweenService\")", meta: "Service" },
                { caption: "Debris", value: "game:GetService(\"Debris\")", meta: "Service" },
                { caption: "Lighting", value: "game:GetService(\"Lighting\")", meta: "Service" },
                { caption: "HttpService", value: "game:GetService(\"HttpService\")", meta: "Service" },
                { caption: "UserInputService", value: "game:GetService(\"UserInputService\")", meta: "Service" },
                { caption: "MarketplaceService", value: "game:GetService(\"MarketplaceService\")", meta: "Service" },
                { caption: "SoundService", value: "game:GetService(\"SoundService\")", meta: "Service" },

                // Common methods
                { caption: "FindFirstChild", value: "FindFirstChild()", meta: "Method" },
                { caption: "WaitForChild", value: "WaitForChild()", meta: "Method" },
                { caption: "Destroy", value: "Destroy()", meta: "Method" },
                { caption: "Clone", value: "Clone()", meta: "Method" },
                { caption: "IsA", value: "IsA()", meta: "Method" },

                // Player-related
                { caption: "LocalPlayer", value: "game:GetService(\"Players\").LocalPlayer", meta: "Roblox" },
                { caption: "Character", value: "game:GetService(\"Players\").LocalPlayer.Character", meta: "Roblox" },
                { caption: "Humanoid", value: "game:GetService(\"Players\").LocalPlayer.Character:FindFirstChild(\"Humanoid\")", meta: "Roblox" },

                // Misc
                { caption: "print", value: "print()", meta: "Lua" },
                { caption: "warn", value: "warn()", meta: "Luau" },
                { caption: "require", value: "require()", meta: "Luau" },
            ]);
        }
    };

    ace.require("ace/ext/language_tools").addCompleter(customCompleter);
    
    // Handle tab clicks and remove button clicks
    tabs.addEventListener('click', function(e) {
        const tab = e.target.closest('.tab');
        if (!tab) return;
        
        // Handle remove button click
        if (e.target.classList.contains('remove-tab')) {
            const tabId = parseInt(tab.dataset.tabId);
            removeTab(tabId);
            return;
        }
        
        // Switch tab
        const tabId = parseInt(tab.dataset.tabId);
        switchTab(tabId);
    });
    
    // Switch to a specific tab
    function switchTab(tabId) {
        // Save current tab content
        tabContents[activeTabId] = editor.getValue();
        
        // Update active tab
        activeTabId = tabId;
        
        // Update tab UI
        document.querySelectorAll('.tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`.tab[data-tab-id="${tabId}"]`).classList.add('active');
        
        // Load tab content
        editor.setValue(tabContents[tabId] || '', -1);
    }
    
    // Remove a tab
    function removeTab(tabId) {
        // Check if this is the last tab
        if (document.querySelectorAll('.tab').length <= 1) {
            return; // Don't remove the last tab
        }
        
        // Remove tab element
        const tabElement = document.querySelector(`.tab[data-tab-id="${tabId}"]`);
        tabElement.remove();
        
        // Delete tab content
        delete tabContents[tabId];
        
        // Decrement tabCount when removing a tab
        tabCount--;
        
        // If the active tab was removed, switch to another tab
        if (activeTabId === tabId) {
            const firstTab = document.querySelector('.tab');
            if (firstTab) {
                switchTab(parseInt(firstTab.dataset.tabId));
            }
        }
        
        // Adjust tab widths after removing a tab
        adjustTabWidths();
    }
    
    // Public API for the editor
    window.TabEditor = {
        SetTheme: function(theme) {
            editor.setTheme(`ace/theme/${theme}`);
        },
        
        GetText: function() {
            return editor.getValue();
        },
        
        SetText: function(text) {
            editor.setValue(text, -1);
            tabContents[activeTabId] = text;
        }
    };
});
