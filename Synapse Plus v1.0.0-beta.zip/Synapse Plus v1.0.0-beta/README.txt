Hello, welcome to Synapse Plus. I am the owner of Team CorgiSide, and I want to thank you for your purchase (if you purchased a license key). Anyway, you can join our Discord at https://discord.gg/SBr3SXFpQA if you need any assistance or help. Anyway, have a nice day!

From, Noah (CorgiSide owner)